﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4_KOZOS_OSZTOK
{
    class Program
    {
        //Kérjünk be két számot, határozzuk meg a közös osztókat oly módon, 
        //hogy először generáljuk le az első szám osztóit egy listába, majd a második szám osztóit,
        //végül vessük össze a két listát, melyek a közös elemek.
        static void Main(string[] args)
        {
            List<int> elso = new List<int>();
            List<int> masodik = new List<int>();
            List<int> azonos = new List<int>();

            Console.WriteLine("#4 Közös osztók");

            Console.Write("\nKérem az eslő számot  : ");
            int szama = int.Parse(Console.ReadLine());
            Console.Write("\nKérem a második számot: ");
            int szamb = int.Parse(Console.ReadLine());
            int futas = 0;
            int futas_db = 0;

            if (szama >= szamb)
            {
                futas = szama;
            }
            else
            {
                futas = szamb;
            }

            for (int i = 1; i < futas+1; i++)
            {
                if (szama % i == 0)
                    elso.Add(i);
                if (szamb % i == 0)
                    masodik.Add(i);
            }
            //for (int i = 1; i < szamb; i++)
            //{
            //    if (szamb % i == 0)
            //        masodik.Add(i);
            //}

            Console.WriteLine();
            for (int i = 0; i < elso.Count; i++)
            {
                for (int j = 0; j < masodik.Count; j++)
                {
                    futas_db++;
                    Console.WriteLine("{0}, {1}",elso[i],masodik[j]);
                    if (elso[i] == masodik[j]) {
                        Console.WriteLine("Találtam párt: {0}, {1}", elso[i], masodik[j]);
                        azonos.Add(elso[i]);
                        break;
                    }
                }
            }

            // kiíratások
            Console.Write("\nElső osztói   : ");
            for (int i = 0; i < elso.Count - 1; i++)
            {
                Console.Write("{0},", elso[i]);
            }
            if (elso.Count != 0)
                Console.WriteLine(elso.Last());


            Console.Write("\nMásodik osztói: ");
            for (int i = 0; i < masodik.Count - 1; i++)
            {
                Console.Write("{0},", masodik[i]);
            }

            if (masodik.Count != 0)
                Console.WriteLine(masodik.Last());


            Console.Write("\nKözös elemek  : ");
            for (int i = 0; i < azonos.Count - 1; i++)
            {
                Console.Write("{0},", azonos[i]);
            }


            if (azonos.Count != 0)
            {
                Console.WriteLine(azonos.Last());
            }
            else
            {
                Console.WriteLine("Nincsen");
            }

            Console.WriteLine("Összfutás szám: {0}", futas_db);
            Console.ReadLine();
        }
    }
}
