﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_sum_click(object sender, RoutedEventArgs e)
        {
            try
            {
                double op1 = double.Parse(a.Text);
                double op2 = double.Parse(b.Text);
                sum.Content = "Eredmény: " + (op1 + op2);
            }
            catch (Exception) { MessageBox.Show("Hibás input!\n\n" + "Szam1: " + a.Text + "\nSzam2: " + b.Text + "\n", "Hiba"); }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                sum.Content = "Eredmény: " + (double.Parse(a.Text) - double.Parse(b.Text));
            }
            catch (Exception) { MessageBox.Show("Hibás input!\n\n" + "Szam1: " + a.Text + "\nSzam2: " + b.Text + "\n", "Hiba"); }
        }
    }
}
