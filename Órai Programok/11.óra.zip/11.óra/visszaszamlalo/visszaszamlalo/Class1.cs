﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace visszaszamlalo
{
    class Esemeny
    {
        public Esemeny(string nev, DateTime date, bool volt)
        {
            this.nev = nev;
            this.date = date;
            this.volt = volt;
        }

        public string nev { get; set; }
        public DateTime date { get; set; }
        public bool volt { get; set; }

        public void eltelt()
        {
            this.volt = true;
        }
    }
}
