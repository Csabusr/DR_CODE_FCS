﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace visszaszamlalo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int jelenlegielem = 0;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string most = DateTime.Now.ToString();
            string most_ev = DateTime.Now.ToString("yyyy");
            string most_honap = DateTime.Now.ToString("MM");
            string most_nap = DateTime.Now.ToString("dd");

            DateTime karacsony = new DateTime(2020, 12, 24);
            DateTime szulinapom = new DateTime(2020, 12, 15);

            Esemeny egyed = new Esemeny("Szülinapom", szulinapom, false);
            Esemeny egyed2 = new Esemeny("Karacsony", karacsony, false);


            List<Esemeny> esemenyek = new List<Esemeny>();

            esemenyek.Add(egyed);
            esemenyek.Add(egyed2);
            lblmost.Content = most;

            // ezt kellet nekem írni

            egyed.nev = esemenyek[jelenlegielem].nev.ToString();
            egyed.date = esemenyek[jelenlegielem].date;
            egyed.volt = esemenyek[jelenlegielem].volt;

            lbleventidopont.Content = egyed.date.ToString();
            lblesemenyneve.Content = egyed.nev.ToString();


            if (egyed.volt == false)
            {
                if (DateTime.Now.ToString("yyyy MM dd") == egyed.date.ToString("yyyy MM dd"))
                { lblevent.Content = "Ma kerül megrendezésre!"; egyed.volt = false; }
                else
                {
                    lblevent.Content =
                        (int.Parse(egyed.date.ToString("yyyy")) - int.Parse(DateTime.Now.ToString("yyyy"))) + " év " +
                        (int.Parse(egyed.date.ToString("MM")) - int.Parse(DateTime.Now.ToString("MM"))) + " hónap " +
                        (int.Parse(egyed.date.ToString("dd")) - int.Parse(DateTime.Now.ToString("dd"))) + " nap van még hátra";
                }
            } 
            else
            {
                lblevent.Content = "Már elmúlt!";
            }


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            jelenlegielem++;
            Button_Click(sender, e);
        }
    }
}
